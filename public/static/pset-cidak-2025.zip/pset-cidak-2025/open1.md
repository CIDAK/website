___________________________________________________________
   ____ ___ ____    _    _   __                            |
  / ___|_ _|  _ \  / \  | \_/ /                            |
 | |    | || | | |/ _ \ |    /                             |
 | |___ | || |_| / ___ \|  _ \                             |  
  \____|___|____/_/   \_\_/ \_\                            |
                                                           |
___________________________________________________________|
This Challenge is a baseline for what a person will expect | 
when joining CIDAK                                         |
                                                           |
We encourage you to struggle and work it out. The use of   | 
AI is allowed, however the use of it in a session with     |
one of the team members is not. This pset you downloaded   |
will give you an idea on the difficulty of the second test | 
session you will take if you are able to get in.           |
                                                           |
Once completed with this test, you can email us, explain   |
to us why you would be a good fit. This isnt a job, but    |
an oppurtunity to meet like minded people.                 |
                                                           |
Email contact@cidak.co with your student email, if you     |
are a past student. Do let us know.                        |
                                                           |
Best wishes going forward.                                 |
                                                           |
___________________________________________________________|
